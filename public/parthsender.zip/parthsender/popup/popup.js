/**
 * Main Controller for Popup UI
 */

document.addEventListener('DOMContentLoaded', async () => {
  console.log('[Popup] Initializing WhatsApp Excel Sender UI...');

  // --- Local State ---
  let state = {
    headers: [],
    rows: [],
    phoneColumn: '',
    defaultCountryCode: '',
    skipDuplicates: true,
    messageTemplate: 'Hello {{Name}},\nThank you for your interest!\nPlease check details.',
    commonImage: null,
    imageMode: 'none', // 'none' | 'common' | 'excel'
    imageColumn: '',
    selectedContactIndices: new Set(),
    queue: [],
    queueState: 'idle', // 'idle' | 'running' | 'paused' | 'completed'
    pacingDelay: 10,
    consentConfirmed: false,
    history: [],
    activeLogFilter: 'all'
  };

  // --- DOM Elements ---
  const els = {
    // Nav
    tabs: document.querySelectorAll('.tab-btn'),
    panels: document.querySelectorAll('.tab-panel'),
    waStatusDot: document.getElementById('wa-status-dot'),
    waStatusText: document.getElementById('wa-status-text'),

    // Import Tab
    dropZone: document.getElementById('drop-zone'),
    fileInput: document.getElementById('excel-file-input'),
    btnBrowse: document.getElementById('btn-browse-file'),
    fileInfo: document.getElementById('file-info'),
    fileName: document.getElementById('file-name'),
    fileSize: document.getElementById('file-size'),
    selectPhoneCol: document.getElementById('select-phone-col'),
    inputDefaultCC: document.getElementById('input-default-cc'),
    checkSkipDuplicates: document.getElementById('check-skip-duplicates'),
    contactsSummaryText: document.getElementById('contacts-summary-text'),
    btnSelectAll: document.getElementById('btn-select-all'),
    btnDeselectAll: document.getElementById('btn-deselect-all'),
    contactsTbody: document.getElementById('contacts-tbody'),
    checkAllTable: document.getElementById('check-all-table'),

    // Composer Tab
    msgTemplate: document.getElementById('message-template'),
    varValidationAlert: document.getElementById('var-validation-alert'),
    varErrorMsg: document.getElementById('var-error-msg'),
    variableChipsList: document.getElementById('variable-chips-list'),
    imageModeRadios: document.querySelectorAll('input[name="image-mode"]'),
    boxCommonImage: document.getElementById('box-common-image'),
    boxExcelImage: document.getElementById('box-excel-image'),
    commonImageInput: document.getElementById('common-image-input'),
    commonImagePreviewBox: document.getElementById('common-image-preview-box'),
    commonImagePreview: document.getElementById('common-image-preview'),
    btnRemoveCommonImage: document.getElementById('btn-remove-common-image'),
    selectImageCol: document.getElementById('select-image-col'),
    previewContactSelect: document.getElementById('preview-contact-select'),
    previewBubbleImageContainer: document.getElementById('preview-bubble-image-container'),
    previewBubbleImage: document.getElementById('preview-bubble-image'),
    previewBubbleText: document.getElementById('preview-bubble-text'),

    // Campaign & Queue Tab
    checkConsent: document.getElementById('check-consent'),
    pacingDelaySlider: document.getElementById('pacing-delay-slider'),
    pacingVal: document.getElementById('pacing-val'),
    btnStartQueue: document.getElementById('btn-start-queue'),
    btnPauseQueue: document.getElementById('btn-pause-queue'),
    btnResumeQueue: document.getElementById('btn-resume-queue'),
    btnStopQueue: document.getElementById('btn-stop-queue'),
    metricTotal: document.getElementById('metric-total'),
    metricSent: document.getElementById('metric-sent'),
    metricFailed: document.getElementById('metric-failed'),
    metricRemaining: document.getElementById('metric-remaining'),
    currentRecipientText: document.getElementById('current-recipient-text'),
    progressBarFill: document.getElementById('progress-bar-fill'),
    progressPercentage: document.getElementById('progress-percentage'),

    // Log Tab
    filterChips: document.querySelectorAll('.filter-chip'),
    logTbody: document.getElementById('log-tbody'),
    btnClearLogs: document.getElementById('btn-clear-logs')
  };

  // --- Initialize App ---
  await loadStateFromStorage();
  setupManagerConnection();
  setupTabNavigation();
  setupExcelImportEvents();
  setupComposerEvents();
  setupQueueEvents();
  setupLogEvents();
  checkWhatsAppWebStatus();

  // Listen to background service worker messages for live queue updates
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.event === 'MANAGER_CONNECTION_CHANGED' && window.renderManagerConnection) window.renderManagerConnection(msg.status, msg.error);
    if (msg.event === 'QUEUE_UPDATED' || msg.event === 'CAMPAIGN_COMPLETED') {
      refreshQueueFromStorage();
    }
  });

  function setupManagerConnection() {
    const dot = document.getElementById('manager-status-dot');
    const label = document.getElementById('manager-status-text');
    const toggle = document.getElementById('manager-connect-toggle');
    const form = document.getElementById('manager-pair-form');
    const input = document.getElementById('manager-pairing-code');
    const error = document.getElementById('manager-connection-error');
    const pairButton = form.querySelector('button[type="submit"]');
    function renderManagerConnection(status, message = '') {
      const connected = status === 'connected';
      if (connected) input.value = '';
      pairButton.disabled = status === 'connecting';
      dot.className = `manager-dot ${connected ? 'connected' : (status === 'connecting' ? 'pending' : '')}`;
      label.textContent = connected ? 'Connected' : status === 'expired' ? 'Connection expired.' : 'Not Connected';
      toggle.textContent = connected ? 'Disconnect' : status === 'expired' ? 'Pair Again' : 'Connect';
      form.classList.toggle('hidden', connected || (status !== 'expired' && form.classList.contains('hidden')));
      error.textContent = message || '';
    }
    window.renderManagerConnection = renderManagerConnection;
    chrome.storage.local.get(['managerConnectionStatus', 'managerConnectionError'], data => {
      renderManagerConnection(data.managerConnectionStatus || 'disconnected', data.managerConnectionError || '');
    });
    toggle.addEventListener('click', () => {
      chrome.storage.local.get(['managerConnectionStatus'], data => {
        if (data.managerConnectionStatus === 'connected') {
          chrome.runtime.sendMessage({ action: 'MANAGER_DISCONNECT' }, () => renderManagerConnection('disconnected'));
        } else {
          form.classList.remove('hidden'); input.focus(); error.textContent = '';
        }
      });
    });
    input.addEventListener('input', () => {
      const raw = input.value.toUpperCase().replace(/[^ABCDEFGHJKLMNPQRTUVWXYZ2346789]/g, '').slice(0, 8);
      input.value = raw.length > 4 ? `${raw.slice(0, 4)}-${raw.slice(4)}` : raw;
    });
    form.addEventListener('submit', event => {
      event.preventDefault(); error.textContent = '';
      renderManagerConnection('connecting');
      chrome.runtime.sendMessage({ action: 'MANAGER_CONNECT', pairingCode: input.value }, response => {
        if (chrome.runtime.lastError) { renderManagerConnection('disconnected', 'Could not start the local connection.'); return; }
        if (!response || !response.success) renderManagerConnection('disconnected', response && response.error || 'Could not connect.');
        else renderManagerConnection('connecting', 'Connecting to ParthSeva Manager…');
      });
    });
  }

  // --- 1. Tab Navigation ---
  function setupTabNavigation() {
    els.tabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        const targetId = tab.getAttribute('data-tab');
        els.tabs.forEach((t) => t.classList.remove('active'));
        els.panels.forEach((p) => p.classList.remove('active'));

        tab.classList.add('active');
        document.getElementById(targetId).classList.add('active');
      });
    });
  }

  // --- 2. WhatsApp Web Status Check ---
  function checkWhatsAppWebStatus() {
    chrome.tabs.query({ url: 'https://web.whatsapp.com/*' }, (tabs) => {
      if (tabs && tabs.length > 0) {
        els.waStatusDot.className = 'status-dot connected';
        els.waStatusText.textContent = 'Web WhatsApp Tab Active';
      } else {
        els.waStatusDot.className = 'status-dot disconnected';
        els.waStatusText.textContent = 'Web WhatsApp Not Open';
      }
    });
  }

  // --- 3. Storage Synchronization ---
  async function loadStateFromStorage() {
    const saved = await Storage.get('appState', null);
    if (saved) {
      state = { ...state, ...saved };
      // selectedContactIndices is a Set but JSON serializes it as {} — restore it properly
      if (!(state.selectedContactIndices instanceof Set)) {
        const raw = state.selectedContactIndices;
        if (Array.isArray(raw)) {
          state.selectedContactIndices = new Set(raw);
        } else {
          state.selectedContactIndices = new Set();
        }
      }
    }

    // Load template
    const savedTemplate = await Storage.get('messageTemplate', null);
    if (savedTemplate !== null) state.messageTemplate = savedTemplate;
    els.msgTemplate.value = state.messageTemplate;

    // Load pacing delay
    const savedDelay = await Storage.get('pacingDelay', 10);
    state.pacingDelay = savedDelay;
    els.pacingDelaySlider.value = savedDelay;
    els.pacingVal.textContent = `${savedDelay}s`;

    // Load history
    state.history = await Storage.get('history', []);

    // Load skipDuplicates & CC settings
    if (state.skipDuplicates !== undefined && els.checkSkipDuplicates) {
      els.checkSkipDuplicates.checked = Boolean(state.skipDuplicates);
    }
    if (state.defaultCountryCode && els.inputDefaultCC) {
      els.inputDefaultCC.value = state.defaultCountryCode;
    }

    // Refresh controls & views
    renderVariableChips();
    validateTemplateVariables();
    updateLivePreview();

    // Fetch active queue status from background
    refreshQueueFromStorage();
  }

  async function saveStateToStorage() {
    await Storage.set('appState', {
      headers: state.headers,
      phoneColumn: state.phoneColumn,
      defaultCountryCode: state.defaultCountryCode,
      skipDuplicates: state.skipDuplicates,
      imageMode: state.imageMode,
      imageColumn: state.imageColumn,
      consentConfirmed: state.consentConfirmed
    });
    await Storage.set('messageTemplate', state.messageTemplate);
    await Storage.set('pacingDelay', state.pacingDelay);
  }

  // --- 4. Excel Import Event Handlers ---
  function setupExcelImportEvents() {
    els.btnBrowse.addEventListener('click', (e) => {
      e.preventDefault();
      els.fileInput.click();
    });

    els.fileInput.addEventListener('change', (e) => {
      if (e.target.files.length > 0) {
        processExcelFile(e.target.files[0]);
      }
    });

    // Drag & drop
    els.dropZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      els.dropZone.classList.add('dragover');
    });
    els.dropZone.addEventListener('dragleave', () => {
      els.dropZone.classList.remove('dragover');
    });
    els.dropZone.addEventListener('drop', (e) => {
      e.preventDefault();
      els.dropZone.classList.remove('dragover');
      if (e.dataTransfer.files.length > 0) {
        processExcelFile(e.dataTransfer.files[0]);
      }
    });

    // Options changes
    els.selectPhoneCol.addEventListener('change', (e) => {
      state.phoneColumn = e.target.value;
      saveStateToStorage();
      renderContactsTable();
      updateLivePreview();
      validateTemplateVariables();
    });

    els.inputDefaultCC.addEventListener('input', (e) => {
      state.defaultCountryCode = e.target.value.trim();
      saveStateToStorage();
      renderContactsTable();
      updateLivePreview();
    });

    els.checkSkipDuplicates.addEventListener('change', (e) => {
      state.skipDuplicates = e.target.checked;
      saveStateToStorage();
      renderContactsTable();
    });

    els.btnSelectAll.addEventListener('click', () => {
      state.rows.forEach((_, i) => state.selectedContactIndices.add(i));
      renderContactsTable();
    });

    els.btnDeselectAll.addEventListener('click', () => {
      state.selectedContactIndices.clear();
      renderContactsTable();
    });

    els.checkAllTable.addEventListener('change', (e) => {
      if (e.target.checked) {
        state.rows.forEach((_, i) => state.selectedContactIndices.add(i));
      } else {
        state.selectedContactIndices.clear();
      }
      renderContactsTable();
    });
  }

  function processExcelFile(file) {
    els.fileName.textContent = file.name;
    els.fileSize.textContent = `${(file.size / 1024).toFixed(1)} KB`;
    els.fileInfo.classList.remove('hidden');

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const buffer = e.target.result;
        const parsed = ExcelParser.parseFile(buffer);

        state.headers = parsed.headers;
        state.rows = parsed.rows;
        state.phoneColumn = parsed.detectedPhoneColumn || (parsed.headers[0] || '');

        // Select all contacts by default
        state.selectedContactIndices = new Set(parsed.rows.map((_, i) => i));

        populateColumnDropdowns();
        renderContactsTable();
        renderVariableChips();
        populatePreviewContactSelector();
        validateTemplateVariables();
        updateLivePreview();
        saveStateToStorage();

        console.log(`[Excel Import] Loaded ${parsed.totalRows} rows. Headers:`, parsed.headers);
      } catch (err) {
        alert(`Error parsing Excel file: ${err.message}`);
        console.error(err);
      }
    };
    reader.readAsArrayBuffer(file);
  }

  function populateColumnDropdowns() {
    // Phone column select
    els.selectPhoneCol.innerHTML = '';
    els.selectPhoneCol.disabled = false;
    state.headers.forEach((h) => {
      const opt = document.createElement('option');
      opt.value = h;
      opt.textContent = h;
      if (h === state.phoneColumn) opt.selected = true;
      els.selectPhoneCol.appendChild(opt);
    });

    // Image column select
    els.selectImageCol.innerHTML = '<option value="">-- Select Column --</option>';
    state.headers.forEach((h) => {
      const opt = document.createElement('option');
      opt.value = h;
      opt.textContent = h;
      if (h === state.imageColumn) opt.selected = true;
      els.selectImageCol.appendChild(opt);
    });
  }

  function renderContactsTable() {
    els.contactsTbody.innerHTML = '';

    if (state.rows.length === 0) {
      els.contactsTbody.innerHTML = `
        <tr>
          <td colspan="5" class="empty-state">
            Please upload an Excel spreadsheet above to preview contacts.
          </td>
        </tr>`;
      els.contactsSummaryText.textContent = 'No contacts imported yet.';
      return;
    }

    const historySet = new Set((state.history || []).map((p) => String(p).trim()));
    const seenPhones = new Set();

    let validCount = 0;
    let duplicateCount = 0;
    let invalidCount = 0;

    const fragment = document.createDocumentFragment();
    const maxPreview = 100;
    const displayRows = state.rows.slice(0, maxPreview);

    displayRows.forEach((row, i) => {
      const tr = document.createElement('tr');

      const rawPhone = row[state.phoneColumn];
      const validRes = Validator.validatePhone(rawPhone, state.defaultCountryCode);
      const isChecked = state.selectedContactIndices.has(i);

      let statusBadge = '';
      if (!validRes.isValid) {
        statusBadge = `<span class="badge badge-danger">Invalid Phone</span>`;
        invalidCount++;
      } else if (state.skipDuplicates && (seenPhones.has(validRes.cleanedPhone) || historySet.has(validRes.cleanedPhone))) {
        statusBadge = `<span class="badge badge-warning">Duplicate (Skip)</span>`;
        duplicateCount++;
      } else {
        statusBadge = `<span class="badge badge-success">Ready</span>`;
        validCount++;
        seenPhones.add(validRes.cleanedPhone);
      }

      // Name or other optional fields summary
      const nameVal = row.Name || row.name || row['Full Name'] || row.ContactName || '';
      const otherKeys = Object.keys(row).filter((k) => k !== state.phoneColumn && k.toLowerCase() !== 'name');
      const summaryText = nameVal ? `<strong>${nameVal}</strong>` : (otherKeys.length > 0 ? `${otherKeys[0]}: ${row[otherKeys[0]]}` : '—');

      tr.innerHTML = `
        <td><input type="checkbox" class="row-checkbox" data-index="${i}" ${isChecked ? 'checked' : ''}></td>
        <td>${i + 1}</td>
        <td><strong>${validRes.cleanedPhone || rawPhone || '—'}</strong></td>
        <td>${summaryText}</td>
        <td>${statusBadge}</td>
      `;

      fragment.appendChild(tr);
    });

    if (state.rows.length > maxPreview) {
      const noteRow = document.createElement('tr');
      noteRow.innerHTML = `<td colspan="5" class="empty-state" style="padding: 10px; font-size: 11px; background: rgba(0,0,0,0.03);">Showing first ${maxPreview} of ${state.rows.length} contacts for performance. All ${state.rows.length} are included in the campaign.</td>`;
      fragment.appendChild(noteRow);
    }

    els.contactsTbody.appendChild(fragment);

    els.contactsSummaryText.textContent = `Total: ${state.rows.length} | Selected: ${state.selectedContactIndices.size} | Valid Ready: ${validCount} | Duplicates: ${duplicateCount}`;

    // Attach row checkbox handlers
    els.contactsTbody.querySelectorAll('.row-checkbox').forEach((cb) => {
      cb.addEventListener('change', (e) => {
        const idx = parseInt(e.target.getAttribute('data-index'), 10);
        if (e.target.checked) {
          state.selectedContactIndices.add(idx);
        } else {
          state.selectedContactIndices.delete(idx);
        }
        renderContactsTable();
        populatePreviewContactSelector();
      });
    });
  }

  // --- 5. Message Composer Event Handlers ---
  function setupComposerEvents() {
    // Template change
    els.msgTemplate.addEventListener('input', (e) => {
      state.messageTemplate = e.target.value;
      saveStateToStorage();
      validateTemplateVariables();
      updateLivePreview();
    });

    // Image Mode Radio handlers
    els.imageModeRadios.forEach((radio) => {
      radio.addEventListener('change', (e) => {
        state.imageMode = e.target.value;
        toggleImageModeBoxes();
        saveStateToStorage();
        updateLivePreview();
      });
    });

    // Common Image File Upload
    els.commonImageInput.addEventListener('change', (e) => {
      if (e.target.files.length > 0) {
        const file = e.target.files[0];
        const reader = new FileReader();
        reader.onload = (event) => {
          state.commonImage = event.target.result;
          els.commonImagePreview.src = state.commonImage;
          els.commonImagePreviewBox.classList.remove('hidden');
          updateLivePreview();
        };
        reader.readAsDataURL(file);
      }
    });

    els.btnRemoveCommonImage.addEventListener('click', () => {
      state.commonImage = null;
      els.commonImageInput.value = '';
      els.commonImagePreviewBox.classList.add('hidden');
      updateLivePreview();
    });

    // Excel Image Column select
    els.selectImageCol.addEventListener('change', (e) => {
      state.imageColumn = e.target.value;
      saveStateToStorage();
      updateLivePreview();
    });

    // Live preview recipient switcher
    els.previewContactSelect.addEventListener('change', () => {
      updateLivePreview();
    });
  }

  function toggleImageModeBoxes() {
    els.boxCommonImage.classList.add('hidden');
    els.boxExcelImage.classList.add('hidden');

    if (state.imageMode === 'common') {
      els.boxCommonImage.classList.remove('hidden');
    } else if (state.imageMode === 'excel') {
      els.boxExcelImage.classList.remove('hidden');
    }
  }

  /**
   * Render dynamic variable chips buttons based on Excel headers
   */
  function renderVariableChips() {
    els.variableChipsList.innerHTML = '';

    if (state.headers.length === 0) {
      els.variableChipsList.innerHTML = '<span class="chip-placeholder">Upload Excel file to view available column variables</span>';
      return;
    }

    state.headers.forEach((h) => {
      const chip = document.createElement('span');
      chip.className = 'var-chip';
      chip.textContent = `{{${h}}}`;
      chip.title = `Click to insert {{${h}}} into message`;

      chip.addEventListener('click', () => {
        insertVariableAtCursor(`{{${h}}}`);
      });

      els.variableChipsList.appendChild(chip);
    });
  }

  /**
   * Inserts text at current cursor position in message textarea
   */
  function insertVariableAtCursor(varText) {
    const textarea = els.msgTemplate;
    const start = textarea.selectionStart || 0;
    const end = textarea.selectionEnd || 0;
    const currentVal = textarea.value;

    const newVal = currentVal.substring(0, start) + varText + currentVal.substring(end);
    textarea.value = newVal;
    state.messageTemplate = newVal;

    // Reset cursor position after inserted text
    textarea.focus();
    textarea.setSelectionRange(start + varText.length, start + varText.length);

    saveStateToStorage();
    validateTemplateVariables();
    updateLivePreview();
  }

  /**
   * Validates variables used in message template against Excel headers
   */
  function validateTemplateVariables() {
    const valRes = Validator.validateVariables(state.messageTemplate, state.headers);

    if (!valRes.isValid) {
      els.varErrorMsg.textContent = `The message uses variable(s) {{${valRes.missingVariables.join('}}, {{')}}} that do NOT exist in the imported Excel file headers!`;
      els.varValidationAlert.classList.remove('hidden');
      els.btnStartQueue.disabled = true;
    } else {
      els.varValidationAlert.classList.add('hidden');
      updateStartButtonState();
    }
  }

  function populatePreviewContactSelector() {
    els.previewContactSelect.innerHTML = '';

    if (state.rows.length === 0) {
      els.previewContactSelect.innerHTML = '<option value="0">Default Preview</option>';
      return;
    }

    state.rows.forEach((row, i) => {
      const name = row.Name || row.name || `Row #${i + 1}`;
      const phone = row[state.phoneColumn] || '';
      const opt = document.createElement('option');
      opt.value = i;
      opt.textContent = `${name} (${phone})`;
      els.previewContactSelect.appendChild(opt);
    });
  }

  /**
   * Live preview box update
   */
  function updateLivePreview() {
    const selectedIndex = parseInt(els.previewContactSelect.value || '0', 10);
    const row = state.rows[selectedIndex] || {};

    // Parsed message text
    const finalMsg = VariableEngine.replaceVariables(state.messageTemplate, row);
    els.previewBubbleText.textContent = finalMsg || '(Message is empty)';

    // Image preview inside bubble
    let imageSrc = null;
    if (state.imageMode === 'common' && state.commonImage) {
      imageSrc = state.commonImage;
    } else if (state.imageMode === 'excel' && state.imageColumn && row[state.imageColumn]) {
      imageSrc = String(row[state.imageColumn]).trim();
    }

    if (imageSrc) {
      els.previewBubbleImage.src = imageSrc;
      els.previewBubbleImageContainer.classList.remove('hidden');
    } else {
      els.previewBubbleImageContainer.classList.add('hidden');
    }
  }

  // --- 6. Campaign & Queue Event Handlers ---
  function setupQueueEvents() {
    els.checkConsent.addEventListener('change', (e) => {
      state.consentConfirmed = e.target.checked;
      saveStateToStorage();
      updateStartButtonState();
    });

    els.pacingDelaySlider.addEventListener('input', (e) => {
      const val = parseInt(e.target.value, 10);
      state.pacingDelay = val;
      els.pacingVal.textContent = `${val}s`;
      saveStateToStorage();
    });

    // Campaign Action Buttons
    els.btnStartQueue.addEventListener('click', async () => {
      console.log('[Campaign] Start button clicked.');

      if (!state.consentConfirmed) {
        alert('Please confirm recipient consent before starting campaign.');
        return;
      }

      if (state.rows.length === 0) {
        alert('Please import contacts from an Excel file first.');
        return;
      }

      // Ensure selectedContactIndices is a real Set (can become plain object after storage restore)
      if (!(state.selectedContactIndices instanceof Set)) {
        console.warn('[Campaign] selectedContactIndices was not a Set — converting...');
        const raw = state.selectedContactIndices;
        state.selectedContactIndices = Array.isArray(raw) ? new Set(raw) : new Set(state.rows.map((_, i) => i));
      }

      const selectedRows = state.rows.filter((_, idx) => state.selectedContactIndices.has(idx));
      console.log(`[Campaign] Total rows: ${state.rows.length} | Selected rows: ${selectedRows.length} | phoneColumn: "${state.phoneColumn}"`);

      if (selectedRows.length === 0) {
        alert('No contacts selected! Please select contacts in Tab 1.');
        return;
      }

      // Refresh history from storage
      state.history = await Storage.get('history', []);

      console.log(`[Campaign] Saving commonImage to dedicated key to avoid per-item quota issues...`);
      // Store commonImage ONCE under its own key (not embedded per queue item)
      const campaignCommonImage = state.imageMode === 'common' ? state.commonImage : null;
      await Storage.set('queueCommonImage', campaignCommonImage);

      // Generate sending queue
      const { items } = QueueManager.createQueue({
        rows: selectedRows,
        phoneColumn: state.phoneColumn,
        messageTemplate: state.messageTemplate,
        skipDuplicates: state.skipDuplicates,
        history: state.history,
        commonImage: state.imageMode === 'common' ? state.commonImage : null,
        imageColumn: state.imageMode === 'excel' ? state.imageColumn : null,
        defaultCountryCode: state.defaultCountryCode
      });

      console.log(`[Campaign] Queue created: ${items.length} items. Statuses:`, items.map(i => i.status));
      console.log(`[Campaign] Sample item[0]:`, items[0]);

      const pendingCount = items.filter((i) => i.status === 'Pending').length;
      if (pendingCount === 0 && items.length > 0) {
        const skippedCount = items.filter((i) => i.status === 'Skipped').length;
        if (skippedCount > 0 && state.skipDuplicates) {
          const proceed = confirm(
            `All ${skippedCount} selected contact(s) were skipped because "Skip Duplicate Phone Numbers" is turned ON and they were already sent or repeated.\n\nWould you like to send to them anyway (turn off skip duplicates for this run)?`
          );
          if (proceed) {
            state.skipDuplicates = false;
            if (els.checkSkipDuplicates) els.checkSkipDuplicates.checked = false;
            saveStateToStorage();
            renderContactsTable();
            // Re-create queue without skipping duplicates
            const recheck = QueueManager.createQueue({
              rows: selectedRows,
              phoneColumn: state.phoneColumn,
              messageTemplate: state.messageTemplate,
              skipDuplicates: false,
              history: state.history,
              commonImage: state.imageMode === 'common' ? state.commonImage : null,
              imageColumn: state.imageMode === 'excel' ? state.imageColumn : null,
              defaultCountryCode: state.defaultCountryCode
            });
            items.length = 0;
            items.push(...recheck.items);
          } else {
            return;
          }
        } else {
          alert('No valid contacts to send to in the selected list.');
          return;
        }
      }

      state.queue = items;
      // Reset all items to Pending status for fresh campaign
      items.forEach(item => {
        item.status = 'Pending';
        item.attempts = 0;
        item.error = null;
        item.sentAt = null;
      });

      console.log(`[Campaign] Saving ${items.length} items to storage with status Pending...`);
      await Storage.set('queue', items);
      await Storage.set('queueState', 'running');
      console.log('[Campaign] Storage saved. Sending START_QUEUE to background...');

      // Trigger background service worker start
      chrome.runtime.sendMessage({ action: 'START_QUEUE' }, (res) => {
        console.log('[Campaign] START_QUEUE response from service worker:', res);
        if (chrome.runtime.lastError) {
          console.error('[Campaign] START_QUEUE error:', chrome.runtime.lastError.message);
        }
        refreshQueueFromStorage();
      });
    });

    els.btnPauseQueue.addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'PAUSE_QUEUE' }, () => refreshQueueFromStorage());
    });

    els.btnResumeQueue.addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'RESUME_QUEUE' }, () => refreshQueueFromStorage());
    });

    els.btnStopQueue.addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'STOP_QUEUE' }, () => refreshQueueFromStorage());
    });
  }

  function updateStartButtonState() {
    const valRes = Validator.validateVariables(state.messageTemplate, state.headers);
    const canStart = state.consentConfirmed && valRes.isValid && state.queueState !== 'running';
    els.btnStartQueue.disabled = !canStart;
  }

  async function refreshQueueFromStorage() {
    chrome.runtime.sendMessage({ action: 'GET_STATUS' }, (data) => {
      if (!data) return;

      const queue = data.queue || [];
      const queueState = data.queueState || 'idle';
      state.queueState = queueState;
      state.queue = queue;

      const stats = QueueManager.calculateStats(queue);

      // Metrics display
      els.metricTotal.textContent = stats.total;
      els.metricSent.textContent = stats.sent;
      els.metricFailed.textContent = stats.failed;
      els.metricRemaining.textContent = stats.remaining;

      // Current Recipient Display
      const processingItem = queue.find((i) => i.status === 'Processing');
      if (processingItem) {
        const name = processingItem.name || processingItem.phone;
        els.currentRecipientText.textContent = `Sending to: ${name} (${processingItem.phone})`;
      } else if (queueState === 'running') {
        els.currentRecipientText.textContent = 'Waiting for pacing delay...';
      } else if (queueState === 'paused') {
        els.currentRecipientText.textContent = 'Campaign Paused';
      } else if (queueState === 'completed') {
        if (stats.sent > 0) {
          els.currentRecipientText.textContent = `Campaign Completed! ${stats.sent} sent${stats.skipped > 0 ? `, ${stats.skipped} skipped` : ''}${stats.failed > 0 ? `, ${stats.failed} failed` : ''}.`;
        } else if (stats.skipped > 0 && stats.sent === 0) {
          els.currentRecipientText.textContent = `Finished: All ${stats.skipped} message(s) were skipped (already sent/duplicates). Turn off "Skip Duplicate Phone Numbers" or Reset History to re-send.`;
        } else {
          els.currentRecipientText.textContent = 'Campaign Completed! All messages processed.';
        }
      } else {
        els.currentRecipientText.textContent = 'None (Idle)';
      }

      // Progress bar percentage
      const completedCount = stats.sent + stats.failed + stats.skipped;
      const pct = stats.total > 0 ? Math.round((completedCount / stats.total) * 100) : 0;
      els.progressBarFill.style.width = `${pct}%`;
      els.progressPercentage.textContent = `${pct}% Completed (${completedCount}/${stats.total})`;

      // Controls visibility
      if (queueState === 'running') {
        els.btnStartQueue.classList.add('hidden');
        els.btnPauseQueue.classList.remove('hidden');
        els.btnResumeQueue.classList.add('hidden');
        els.btnStopQueue.disabled = false;
      } else if (queueState === 'paused') {
        els.btnStartQueue.classList.add('hidden');
        els.btnPauseQueue.classList.add('hidden');
        els.btnResumeQueue.classList.remove('hidden');
        els.btnStopQueue.disabled = false;
      } else {
        els.btnStartQueue.classList.remove('hidden');
        els.btnPauseQueue.classList.add('hidden');
        els.btnResumeQueue.classList.add('hidden');
        els.btnStopQueue.disabled = true;
      }

      updateStartButtonState();
      renderLogTable(queue);
    });
  }

  // --- 7. Activity Log & Reset Event Handlers ---
  function setupLogEvents() {
    els.filterChips.forEach((chip) => {
      chip.addEventListener('click', () => {
        els.filterChips.forEach((c) => c.classList.remove('active'));
        chip.classList.add('active');
        state.activeLogFilter = chip.getAttribute('data-filter');
        renderLogTable(state.queue);
      });
    });

    const resetCampaign = async () => {
      if (confirm('Are you sure you want to reset the campaign, clear logs, and clear send history?')) {
        await Storage.set('queue', []);
        await Storage.set('history', []);
        await Storage.set('queueState', 'idle');
        state.queue = [];
        state.history = [];
        state.queueState = 'idle';

        chrome.runtime.sendMessage({ action: 'STOP_QUEUE' }, () => {
          refreshQueueFromStorage();
          renderContactsTable();
        });
      }
    };

    els.btnClearLogs?.addEventListener('click', resetCampaign);

    const btnResetCard = document.getElementById('btn-reset-campaign');
    if (btnResetCard) {
      btnResetCard.addEventListener('click', resetCampaign);
    }
  }

  function renderLogTable(queue = []) {
    els.logTbody.innerHTML = '';

    const filter = state.activeLogFilter;
    const filtered = queue.filter((item) => filter === 'all' || item.status === filter);

    if (filtered.length === 0) {
      els.logTbody.innerHTML = `<tr><td colspan="5" class="empty-state">No log entries for filter "${filter}".</td></tr>`;
      return;
    }

    const fragment = document.createDocumentFragment();
    const maxLogDisplay = 150;
    // Show most recent / active first or limit to maxLogDisplay
    const displayList = filtered.slice(0, maxLogDisplay);

    displayList.forEach((item) => {
      const tr = document.createElement('tr');

      let badgeClass = 'badge-info';
      if (item.status === 'Sent') badgeClass = 'badge-success';
      if (item.status === 'Failed') badgeClass = 'badge-danger';
      if (item.status === 'Skipped') badgeClass = 'badge-warning';

      const timeStr = item.sentAt ? new Date(item.sentAt).toLocaleTimeString() : '—';
      const details = item.error ? `<span class="required">${item.error}</span>` : (item.status === 'Sent' ? 'Sent successfully' : 'Queued');

      tr.innerHTML = `
        <td>${item.index}</td>
        <td><strong>${item.phone}</strong></td>
        <td><span class="badge ${badgeClass}">${item.status}</span></td>
        <td>${details}</td>
        <td>${timeStr}</td>
      `;

      fragment.appendChild(tr);
    });

    if (filtered.length > maxLogDisplay) {
      const noteRow = document.createElement('tr');
      noteRow.innerHTML = `<td colspan="5" class="empty-state" style="padding: 8px; font-size: 11px;">Showing first ${maxLogDisplay} of ${filtered.length} entries for responsiveness. Metrics reflect all items.</td>`;
      fragment.appendChild(noteRow);
    }

    els.logTbody.appendChild(fragment);
  }
});
