/**
 * Content script injected into https://web.whatsapp.com/*
 * Version 1.5 - Fix for duplicate text in image caption box
 */

(function () {
  console.log('[WhatsApp Content Script] Active v1.5 (Caption Duplication Fix)');

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'PING') {
      sendResponse({ status: 'PONG', loggedIn: isWhatsAppLoggedIn() });
      return true;
    }

    if (request.action === 'CHECK_STATUS') {
      sendResponse({ loggedIn: isWhatsAppLoggedIn(), ready: isWhatsAppReady() });
      return true;
    }

    if (request.action === 'NAVIGATE_TO_PHONE') {
      const { url } = request.payload;
      // Match the archived working flow: WhatsApp Web parses /send?phone= during navigation.
      // A synthetic history event changes the URL but does not reliably open the chat.
      sendResponse({ success: true });
      window.location.assign(url);
      return false;
    }

    if (request.action === 'SEND_MESSAGE') {
      handleSendMessage(request.payload)
        .then((result) => sendResponse(result))
        .catch((err) => sendResponse({ success: false, error: err.message || 'DOM execution error' }));
      return true;
    }
  });

  function isWhatsAppLoggedIn() {
    return !!(
      document.querySelector('#app') &&
      !document.querySelector('div[data-ref]') &&
      (document.querySelector('#pane-side') || document.querySelector('#main') || document.querySelector('div[data-tab="1"]'))
    );
  }

  function isWhatsAppReady() {
    return isWhatsAppLoggedIn() && !document.querySelector('div[data-animate-modal-popup="true"]');
  }

  /**
   * Primary Send Dispatcher
   */
  async function handleSendMessage({ phone, text, image }) {
    console.log(`[WhatsApp Content Script] Processing message (Image attached: ${!!image})`);

    if (!isWhatsAppLoggedIn()) {
      const loggedIn = await waitForCondition(() => isWhatsAppLoggedIn(), 15000);
      if (!loggedIn) {
        return { success: false, error: 'WhatsApp Web is not logged in' };
      }
    }

    // Step 1: Wait for chat window or invalid phone popup
    const loadResult = await waitForChatOrInvalidPhonePopup(25000);
    if (!loadResult.success) {
      return loadResult;
    }

    await sleep(1200);

    // Step 2: Image + Caption Send Flow
    if (image) {
      console.log('[WhatsApp Content Script] Executing single image attachment flow...');
      const imageResult = await attachAndSendImageWithCaption(image, text);
      await sleep(2500);
      return imageResult;
    }

    // Step 3: Text Only Send Flow
    console.log('[WhatsApp Content Script] Executing text-only send flow...');
    const textResult = await sendTextMessage(text);
    await sleep(2500);
    return textResult;
  }

  /**
   * Waits for chat pane or invalid phone error popup
   */
  async function waitForChatOrInvalidPhonePopup(timeoutMs = 25000) {
    const startTime = Date.now();

    while (Date.now() - startTime < timeoutMs) {
      const invalidModal = findInvalidPhoneModal();
      if (invalidModal) {
        dismissModal(invalidModal);
        return { success: false, error: 'Phone number is invalid or not registered on WhatsApp' };
      }

      const composeBox = findComposeBox();
      if (composeBox) {
        return { success: true };
      }

      await sleep(500);
    }

    return { success: false, error: 'Timeout waiting for chat pane to load' };
  }

  function findInvalidPhoneModal() {
    const dialogs = document.querySelectorAll('div[role="dialog"], div[data-animate-modal-popup="true"]');
    for (const dialog of dialogs) {
      const txt = (dialog.textContent || '').toLowerCase();
      if (
        txt.includes('invalid') ||
        txt.includes("phone number shared via url is invalid") ||
        txt.includes("url is invalid") ||
        txt.includes("couldn't find") ||
        (txt.includes("starting chat") === false && txt.includes("phone number"))
      ) {
        return dialog;
      }
    }
    return null;
  }

  function dismissModal(dialog) {
    try {
      const btn = dialog.querySelector('button, div[role="button"]');
      if (btn) clickElement(btn);
    } catch (e) {}
  }

  function findComposeBox() {
    return (
      document.querySelector('#main footer div[contenteditable="true"]') ||
      document.querySelector('footer div[contenteditable="true"][data-tab="10"]') ||
      document.querySelector('footer div[contenteditable="true"]') ||
      document.querySelector('div[contenteditable="true"][data-tab="10"]') ||
      document.querySelector('div[title="Type a message"]') ||
      document.querySelector('div[aria-placeholder="Type a message"]')
    );
  }

  /**
   * Duplicate-proof helper to set text in caption box
   */
  function setCaptionText(captionBox, text) {
    if (!captionBox || !text) return;

    captionBox.focus();

    const currentText = (captionBox.textContent || '').trim();
    const targetText = text.trim();

    // If text is already present and matches, do not duplicate!
    if (currentText === targetText) {
      console.log('[WhatsApp Content Script] Caption already matches target text');
      return;
    }

    // Clear existing content cleanly
    try {
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(captionBox);
      sel.removeAllRanges();
      sel.addRange(range);
      document.execCommand('delete', false, null);
    } catch (e) {}

    // Insert text with preserved line gaps
    insertMultilineText(captionBox, text);
    captionBox.dispatchEvent(new Event('input', { bubbles: true }));
  }

  /**
   * Helper to set text in main contenteditable element
   */
  function setTextInContentEditable(el, text) {
    if (!el || text === undefined || text === null) return false;
    try {
      el.focus();
      const currentText = (el.textContent || '').trim();
      if (currentText === text.trim()) return true;

      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(el);
      sel.removeAllRanges();
      sel.addRange(range);

      document.execCommand('delete', false, null);
      insertMultilineText(el, text);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    } catch (e) {
      console.error('setTextInContentEditable error:', e);
      return false;
    }
  }

  function insertMultilineText(el, text) {
    const cleanText = String(text || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    const lines = cleanText.split('\n');
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].length > 0) {
        document.execCommand('insertText', false, lines[i]);
      }
      if (i < lines.length - 1) {
        document.execCommand('insertLineBreak', false, null);
      }
    }
  }

  /**
   * Helper to click element with full synthetic event triggers
   */
  function clickElement(el) {
    if (!el) return false;
    try { el.focus(); } catch (e) {}
    try { el.click(); } catch (e) {}
    try {
      el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
      el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
      el.dispatchEvent(new PointerEvent('click', { bubbles: true, cancelable: true }));
    } catch (e) {}
    return true;
  }

  /**
   * Sends text-only message
   */
  async function sendTextMessage(text) {
    const composeBox = findComposeBox();
    if (!composeBox) {
      return { success: false, error: 'Message compose box not found' };
    }

    composeBox.focus();

    const currentText = composeBox.textContent || '';
    if (text && (!currentText || currentText.trim() === '')) {
      setTextInContentEditable(composeBox, text);
      await sleep(400);
    }

    const sendBtn = findSendButton();
    if (sendBtn) {
      console.log('[WhatsApp Content Script] Clicking text send button');
      clickElement(sendBtn);
      return { success: true };
    }

    // Fallback: Enter keypress
    console.log('[WhatsApp Content Script] Simulating Enter keypress');
    const enterDown = new KeyboardEvent('keydown', {
      key: 'Enter',
      keyCode: 13,
      code: 'Enter',
      which: 13,
      bubbles: true,
      cancelable: true
    });
    composeBox.dispatchEvent(enterDown);

    return { success: true };
  }

  function findSendButton() {
    return (
      document.querySelector('footer button span[data-icon="send"]')?.closest('button') ||
      document.querySelector('#main footer span[data-icon="send"]')?.closest('button') ||
      document.querySelector('span[data-icon="send"]')?.closest('button') ||
      document.querySelector('button[aria-label="Send"]') ||
      document.querySelector('footer button[aria-label="Send"]') ||
      document.querySelector('span[data-icon="send"]')?.parentElement
    );
  }

  /**
   * Attaches SINGLE image and sets text as caption before clicking Send
   */
  async function attachAndSendImageWithCaption(imageDataUrl, text) {
    const composeBox = findComposeBox();
    if (!composeBox) {
      return { success: false, error: 'Compose box not found' };
    }

    try {
      const file = await urlToFile(imageDataUrl, 'attachment.png');
      let previewOpened = false;

      // Clear any pre-existing text in main compose box
      if (composeBox.textContent && composeBox.textContent.trim() !== '') {
        try {
          composeBox.focus();
          document.execCommand('selectAll', false, null);
          document.execCommand('delete', false, null);
        } catch (e) {}
      }

      // Method A: Clipboard paste
      console.log('[WhatsApp Content Script] Method A: Image Paste');
      const dtPaste = new DataTransfer();
      dtPaste.items.add(file);

      const pasteEvent = new ClipboardEvent('paste', {
        clipboardData: dtPaste,
        bubbles: true,
        cancelable: true
      });

      composeBox.focus();
      composeBox.dispatchEvent(pasteEvent);

      previewOpened = await waitForCondition(() => findMediaPreviewSendButton() !== null, 4000);

      // Method B ONLY if Method A did not open media viewer:
      if (!previewOpened) {
        console.log('[WhatsApp Content Script] Method B: Attach (+) Menu Input');
        const attachBtn = document.querySelector('button[title="Attach"]') ||
                          document.querySelector('button[aria-label="Attach"]') ||
                          document.querySelector('span[data-icon="plus"]')?.closest('button') ||
                          document.querySelector('span[data-icon="attach-menu-plus"]')?.closest('button') ||
                          document.querySelector('span[data-icon="clip"]')?.closest('button');

        if (attachBtn) {
          clickElement(attachBtn);
          await sleep(600);

          const fileInput = document.querySelector('input[type="file"][accept*="image"]') ||
                            document.querySelector('input[type="file"]');
          if (fileInput) {
            const dt = new DataTransfer();
            dt.items.add(file);
            fileInput.files = dt.files;
            fileInput.dispatchEvent(new Event('change', { bubbles: true }));
            fileInput.dispatchEvent(new Event('input', { bubbles: true }));

            previewOpened = await waitForCondition(() => findMediaPreviewSendButton() !== null, 4000);
          }
        }
      }

      if (!previewOpened) {
        return { success: false, error: 'Could not open image media preview screen in WhatsApp' };
      }

      console.log('[WhatsApp Content Script] Media Preview Overlay Screen Active!');
      await sleep(600);

      // Populate Caption Box in Media Preview Screen cleanly without duplicating
      const captionBox = findMediaCaptionBox();
      if (captionBox && text) {
        console.log('[WhatsApp Content Script] Setting caption text...');
        setCaptionText(captionBox, text);
        await sleep(500);
      }

      // Click Send Button in Media Preview Window (retry up to 4s in case animation is completing)
      console.log('[WhatsApp Content Script] Clicking Media Preview Send Button...');
      let sent = false;
      for (let attempt = 0; attempt < 8; attempt++) {
        sent = clickMediaSendButton();
        if (sent) break;
        await sleep(500);
      }
      
      if (sent) {
        await sleep(2500);
        return { success: true };
      } else {
        // Fallback: Dispatch Enter key in caption box or active element
        console.log('[WhatsApp Content Script] Fallback: Enter keypress in caption box / focused element');
        const targetBox = captionBox || document.activeElement || findComposeBox();
        if (targetBox) {
          try { targetBox.focus(); } catch (e) {}
          const enterDown = new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true });
          const enterPress = new KeyboardEvent('keypress', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true });
          const enterUp = new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true });
          targetBox.dispatchEvent(enterDown);
          targetBox.dispatchEvent(enterPress);
          targetBox.dispatchEvent(enterUp);
          await sleep(2500);
          return { success: true };
        }
        return { success: false, error: 'Media preview send button not found' };
      }

    } catch (err) {
      console.error('[WhatsApp Content Script] attachAndSendImage error:', err);
      return { success: false, error: err.message || 'Image attachment failed' };
    }
  }

  function clickMediaSendButton() {
    const btn = findMediaPreviewSendButton();
    if (btn) {
      console.log('[WhatsApp Content Script] Found media preview send button, clicking...', btn);
      clickElement(btn);
      return true;
    }
    return false;
  }

  function findMediaPreviewSendButton() {
    // 1. Check inside media containers / modals / dialogs first
    const containers = [
      document.querySelector('div[data-animate-media-viewer="true"]'),
      document.querySelector('div[role="dialog"]'),
      document.querySelector('div[aria-label="Media preview"]'),
      document.querySelector('span[data-animate-media-viewer="true"]'),
      document.querySelector('#app')
    ].filter(Boolean);

    for (const container of containers) {
      // Common WhatsApp Send icons and labels
      const candidates = [
        container.querySelector('div[aria-label="Send"]'),
        container.querySelector('button[aria-label="Send"]'),
        container.querySelector('span[data-icon="send"]')?.closest('div[role="button"]'),
        container.querySelector('span[data-icon="send"]')?.closest('button'),
        container.querySelector('span[data-icon="send"]')?.parentElement,
        container.querySelector('span[data-icon="round-send-inverted"]')?.closest('div[role="button"]'),
        container.querySelector('span[data-icon="round-send-inverted"]')?.closest('button'),
        container.querySelector('span[data-icon="wds-ic-send-filled"]')?.closest('div[role="button"]'),
        container.querySelector('span[data-icon="wds-ic-send-filled"]')?.closest('button')
      ];

      for (const el of candidates) {
        if (el && el.offsetParent !== null) { // visible in DOM
          return el;
        }
      }
    }

    // 2. Global search in document
    const globalCandidates = [
      document.querySelector('div[aria-label="Send"]'),
      document.querySelector('button[aria-label="Send"]'),
      document.querySelector('span[data-icon="send"]')?.closest('div[role="button"]'),
      document.querySelector('span[data-icon="send"]')?.closest('button'),
      document.querySelector('span[data-icon="round-send-inverted"]')?.closest('div[role="button"]'),
      document.querySelector('span[data-icon="wds-ic-send-filled"]')?.closest('div[role="button"]'),
      document.querySelector('div[role="button"][data-tab="11"]')
    ];

    for (const el of globalCandidates) {
      if (el) return el;
    }

    // 3. Fallback: Search all buttons / role="button" elements that have an SVG with a send path
    const allButtons = document.querySelectorAll('div[role="button"], button');
    for (const b of allButtons) {
      const svg = b.querySelector('svg');
      if (svg) {
        const title = svg.getAttribute('aria-label') || b.getAttribute('aria-label') || '';
        if (title.toLowerCase().includes('send')) {
          return b;
        }
        // In media viewer, the send button is typically green circular button with path M1.101...
        const path = svg.querySelector('path');
        const pathData = path ? path.getAttribute('d') || '' : '';
        if (pathData.includes('1.101') || pathData.includes('M1.101') || pathData.includes('1.101 21.757')) {
          return b;
        }
      }
    }

    return null;
  }

  function findMediaCaptionBox() {
    const mediaContainer = document.querySelector('div[data-animate-media-viewer="true"]') ||
                           document.querySelector('div[role="dialog"]') ||
                           document.querySelector('div[aria-label="Media preview"]') ||
                           document.body;

    return (
      mediaContainer.querySelector('div[aria-placeholder="Add a caption"]') ||
      mediaContainer.querySelector('div[title="Add a caption"]') ||
      mediaContainer.querySelector('div[contenteditable="true"]') ||
      document.querySelector('div[aria-placeholder="Add a caption"]') ||
      document.querySelector('div[title="Add a caption"]') ||
      document.querySelector('div[contenteditable="true"][data-tab="6"]') ||
      document.querySelector('div[contenteditable="true"][data-tab="10"]')
    );
  }

  async function urlToFile(url, filename) {
    if (url.startsWith('data:')) {
      const arr = url.split(',');
      const mime = arr[0].match(/:(.*?);/)[1];
      const bstr = atob(arr[1]);
      let n = bstr.length;
      const u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      return new File([u8arr], filename, { type: mime });
    } else {
      const res = await fetch(url);
      const blob = await res.blob();
      return new File([blob], filename, { type: blob.type || 'image/png' });
    }
  }

  function waitForCondition(fn, timeoutMs = 10000, intervalMs = 300) {
    return new Promise((resolve) => {
      const start = Date.now();
      const timer = setInterval(() => {
        if (fn()) {
          clearInterval(timer);
          resolve(true);
        } else if (Date.now() - start >= timeoutMs) {
          clearInterval(timer);
          resolve(false);
        }
      }, intervalMs);
    });
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
})();
